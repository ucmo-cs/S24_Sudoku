package solver.sudokuteacher.SolvingStrategiesModels;

public class NakedPairModel extends StrategyModel{

    public NakedPairModel(String strategyName) {
        super(strategyName);
    }

    @Override
    public String toString(){
        return "";
    }
}
