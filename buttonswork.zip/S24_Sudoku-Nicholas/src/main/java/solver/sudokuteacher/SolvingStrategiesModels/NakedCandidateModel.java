package solver.sudokuteacher.SolvingStrategiesModels;

public class NakedCandidateModel extends StrategyModel{

    public NakedCandidateModel(String strategyName) {
        super(strategyName);
    }
}
